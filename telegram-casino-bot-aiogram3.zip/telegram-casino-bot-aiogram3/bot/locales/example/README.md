> 🇷🇺 README на русском доступен [здесь](README.ru.md)

In this directory you can find sample localization files for EN and RU languages.

To use them in your bot, create a new directory with language code, e.g. "en" in "locales" parent folder 
(e.g. "bot/locales/en"). Then put your or sample .ftl file in that directory (e.g. "strings.ftl"). 
Finally, update your `.env` file to load localization from your folder.
